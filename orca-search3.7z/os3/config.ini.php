<?php /* **************************************************************
 * Orca Search - User Configuration
 *
 */

/* ***** MySQL ***************************************************** */
$_DDATA['hostname'] = 'localhost';
$_DDATA['username'] = 'username';
$_DDATA['password'] = 'password';
$_DDATA['database'] = 'database';
$_DDATA['tbprefix'] = 'os_';


/* ***** Administration ******************************************** */
$_RDATA['admin_username'] = 'admin';
$_RDATA['admin_password'] = 'password';

?>